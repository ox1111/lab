import gdb

class auto(gdb.Command):
    def __init__(self):
        super().__init__("auto_analyze", gdb.COMMAND_USER)

    def invoke(self, arg, from_tty):
        gdb.execute("set disassembly-flavor intel")
        gdb.execute("break _start")
        gdb.execute("run")
        gdb.execute("echo \\n▶ disassembly of _start:\\n")
        gdb.execute("disas")

        gdb.execute("echo \\n▶ memory (x/3xb 0x0000000000401007):\\n")
        gdb.execute("x/3xb 0x0000000000401007")

        gdb.execute("echo \\n▶ memory (x/xb 0x0000000000401007):\\n")
        gdb.execute("x/xb 0x0000000000401007")

        gdb.execute("echo \\n▶ memory (x/xb 0x0000000000401008):\\n")
        gdb.execute("x/xb 0x0000000000401008")

        gdb.execute("echo \\n▶ memory (x/xb 0x0000000000401009):\\n")
        gdb.execute("x/xb 0x0000000000401009")


        #gdb.execute("echo \\n▶ instruction stream (x/10i $rip):\\n")
        #gdb.execute("x/10i $rip")
        #gdb.execute("echo \\n▶ Done.\\n")

auto()

