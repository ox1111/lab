nasm -f elf64 rep_f3.asm -o rep_f3.o
ld rep_f3.o -o rep_f3
