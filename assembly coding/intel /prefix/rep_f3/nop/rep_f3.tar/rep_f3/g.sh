gdb ./rep_f3 -x gdb.py
