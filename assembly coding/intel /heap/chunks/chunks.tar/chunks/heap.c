#include <stdlib.h>
#include <stdio.h>

int main() {

    char *a = malloc(32);

    getchar(); // 멈춤
    return 0;
}


